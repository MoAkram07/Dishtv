﻿using System;

namespace absolute_value
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.Write("enter the number :");
            num = Convert.ToInt32(Console.ReadLine());
            Console.Write("absolute value is :",num, Math.Abs(num));
        }
    }
}
