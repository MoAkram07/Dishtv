﻿using System;

namespace largestof3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2,num3;
            Console.WriteLine("Enter three numbers :");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine()); 
            num3 = Convert.ToInt32(Console.ReadLine());
            if (num1 > num2 && num1>num3)
            {
                Console.WriteLine("largest number is :" + num1);

            }
            else if(num2>num1 && num2>num3)
            {
                Console.WriteLine("largest number is " + num2);
            }
            else
            {
                Console.WriteLine("largest number is " + num3);
            }

        }
    }
}
