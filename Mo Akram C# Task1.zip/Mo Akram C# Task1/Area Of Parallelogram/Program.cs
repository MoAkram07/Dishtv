﻿using System;

namespace Area_Of_Parallelogram
{
    class Program
    {
        static void Main(string[] args)
        {
            double b, h, area;
            Console.WriteLine("Enter Base Value");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Hight Value");
            h = double.Parse(Console.ReadLine());
            area = b * h;
            Console.WriteLine("Area Of Parallelogram "+area);
        }
    }
}
