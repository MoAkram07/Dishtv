﻿using System;

namespace Armstrong_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, r, sum = 0, temp;
            Console.Write("Enter the number :");
            num = int.Parse(Console.ReadLine());
            temp = num;
            while (num > 0)
            {
                r = num % 10;
                sum = sum + (r * r * r);
                num = num / 10;
            }
            if (temp == sum)
            {
                Console.Write("Armstrong Number");
            }
            else
            {
                Console.Write("Not Armstrong Number");
            }
        }
    }
}
