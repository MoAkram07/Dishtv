﻿using System;

namespace Compound_interest
{
    class Program
    {
        static void Main(string[] args)
        {
            double ci, amount, p, r;
            int n, t;
            Console.Write("Enter the principal balance = ");
            p = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter interest rate= ");
            r = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter compound frequency/year ");
            n = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the year= ");
            t = Convert.ToInt32(Console.ReadLine());

            //calculating compound value using formula
            amount = p * Math.Pow((1 + r / (100 * n)), n * t);

            //find the compound interest
            ci = amount - p;

            //display result upto 2 decimal places 
            Console.WriteLine("Compound interest = " + Math.Round(ci, 2));

            Console.ReadKey();
        }
    }
}
