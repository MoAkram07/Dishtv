﻿using System;

namespace even_odd
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter an Number :");
            num = Convert.ToInt32(Console.ReadLine());
            if(num%2==0)
            {
                Console.Write("{0} is even number", num);
            }
            else
            {
                Console.Write("{0} is odd number ", num);
            }
        }
    }
}
