﻿using System;

namespace Perimeter_of_Rhombus
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, perimeter;
            Console.Write("Enter side of Rhombus: ");
            a = Convert.ToInt32(Console.ReadLine());
            perimeter = 4 * a;
            Console.WriteLine("The perimeter of rhombus " +
                              "with side " + a + " is " + perimeter + ".");
        }
    }
}
