﻿using System;

namespace Cube_of_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int num,cube;
            Console.WriteLine("Enter the number :");
            num = Convert.ToInt32(Console.ReadLine());
            cube = num * num * num;
            Console.WriteLine("Cube of the number :" + cube);
        }
    }
}
