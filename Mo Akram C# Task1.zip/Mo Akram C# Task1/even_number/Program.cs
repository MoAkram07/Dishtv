﻿using System;

namespace even_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.Write("Enter the number :");
            num = Convert.ToInt32(Console.ReadLine());
            for(int i=1;i<=num;i++)
            if(i%2==0)
                {
                    Console.WriteLine(i);
                }
        }
    }
}
