﻿using System;

namespace Simple_Intrest
{
    class Program
    {
        static void Main(string[] args)
        {
            double si, principleamount, time, rate;
            Console.WriteLine("Enter principle amount :");
            principleamount = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter time:");
            time = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter rate :");
            rate = Convert.ToDouble(Console.ReadLine());

            si = (principleamount * time * rate) / 100;
            Console.WriteLine("simple interest = " + si);
        }
    }
}
