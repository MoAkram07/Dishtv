﻿using System;

namespace leapYear
{
    class Program
    {
        static void Main(string[] args)
        {
            int year;
            Console.Write("Enter the year :");
            year = Convert.ToInt32(Console.ReadLine());

            if(year%400==0)
            {
                Console.Write("{0} is a leap year.\n", year);

            }
            else if (year % 100 == 0)
            {
                Console.Write("{0} is a leap year.\n", year);

            }
            else if (year % 4 == 0)
            {
                Console.Write("{0} is a leap year.\n", year);

            }
            else
            {
                Console.Write("{0} is not a leap year.\n", year);

            }
        }
    }
}
