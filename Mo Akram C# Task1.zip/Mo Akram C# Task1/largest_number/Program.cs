﻿using System;

namespace largest_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Console.WriteLine("Enter two numbers :");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());
            if(num1>num2)
            {
                Console.WriteLine("largest number is :"+num1);

            }
            else
            {
                Console.WriteLine("largest number is "+num2);
            }
        }
    }
}
