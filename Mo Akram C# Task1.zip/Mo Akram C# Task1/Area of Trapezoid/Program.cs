﻿using System;

namespace Area_of_Trapezoid
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, h, area;
            Console.WriteLine("Enter First Base Value");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Second Base Value");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Hight Value");
            h = double.Parse(Console.ReadLine());
            area = ((a + b) / 2) * h;
            Console.WriteLine("Area of Trapezoid "+area);
        }
    }
}
