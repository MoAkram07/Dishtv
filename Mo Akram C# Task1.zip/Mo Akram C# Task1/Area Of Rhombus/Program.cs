﻿using System;

namespace Area_Of_Rhombus
{
    class Program
    {
        static void Main(string[] args)
        {
            double d1, d2, area;
            Console.WriteLine("Enter first Diagonal");
            d1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Second Diagonal");
            d2 = Convert.ToDouble(Console.ReadLine());
            area = (d1 * d2) / 2;
            Console.WriteLine("Area Of Rhombus is =" +area);


        }
    }
}
